INSERT INTO tor_cat(hotel_id,hotel_name,hotel_Address,hotel_rating) VALUES(1001,'Taj','Nashik',4);
INSERT INTO tor_cat(hotel_id,hotel_name,hotel_Address,hotel_rating) VALUES(1002,'ExpressIN','Nashik',5);
INSERT INTO tor_cat(hotel_id,hotel_name,hotel_Address,hotel_rating) VALUES(1003,'BlueLeaf','Nashik',3);